async function generateWorkout() {

    try {

        const response = await fetch("/generate-workout", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                user_id: "demo-user",
                goal: "muscle_gain",
                level: "beginner",
                duration: 45
            })
        });

        const data = await response.json();

        console.log("Workout:", data);

        // Later we will display the API response
        // directly inside the workout cards.

    } catch (error) {

        console.error("Workout generation failed:", error);

    }
}