# FitBuddy AI

FitBuddy AI is an AI-powered fitness plan generator built with **FastAPI, SQLite, Jinja2, and Google Gemini**.

It collects basic fitness information, generates a 7-day workout plan and nutrition/recovery guidance, and lets users submit feedback to update their plan.

## Features

- 🏋️ AI-generated workout plans
- 🥗 AI-generated nutrition/recovery tips
- 🔄 Update workout plans using user feedback
- 💾 SQLite database for users and generated plans
- 🖥️ Simple HTML/CSS/JavaScript web interface
- 🔐 Token-protected admin dashboard
- ❤️ Health-check endpoint
- 🧩 Local fallback behavior when a Gemini API key is not configured

## Project Structure

```text
FitBuddy-AI/
├── app/
│   ├── ai/
│   │   ├── gemini_client.py
│   │   ├── gemini_flash_generator.py
│   │   ├── gemini_generator.py
│   │   └── updated_plan.py
│   ├── config.py
│   ├── database.py
│   ├── main.py
│   ├── routes.py
│   └── schemas.py
├── static/
│   ├── workout.css
│   └── workout.js
├── templates/
│   ├── admin_login.html
│   ├── all_users.html
│   ├── index.html
│   ├── result.html
│   └── workout.html
├── .env.example
├── .gitignore
├── README.md
└── requirements.txt
```

## Requirements

- Python 3.10+
- A Google Gemini API key (optional; required for live AI generation)

## Installation

### 1. Clone the repository

```bash
git clone https://github.com/YOUR-USERNAME/FitBuddy-AI.git
cd FitBuddy-AI
```

### 2. Create a virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure environment variables

Copy `.env.example` to `.env`.

Windows:

```bash
copy .env.example .env
```

macOS/Linux:

```bash
cp .env.example .env
```

Then edit `.env`:

```env
APP_NAME=FitBuddy AI
DATABASE_URL=sqlite:///./fitbuddy.db
ADMIN_TOKEN=change-this-to-a-real-secret
GEMINI_API_KEY=your-gemini-api-key
WORKOUT_MODEL=gemini-2.0-flash
NUTRITION_MODEL=gemini-2.0-flash
```

**Never commit `.env` or API keys to GitHub.**

You can get a Gemini API key from Google AI Studio:
https://aistudio.google.com/apikey

### 5. Start the application

```bash
uvicorn app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

## Useful Endpoints

| Endpoint | Method | Purpose |
|---|---|---|
| `/` | GET | Home page |
| `/workout` | GET | Workout page |
| `/generate-workout` | POST | Generate a workout plan |
| `/submit-feedback` | POST | Update a plan using feedback |
| `/view-all-users` | GET | Admin dashboard |
| `/admin/delete/{user_id}` | POST | Delete a user |
| `/api/health` | GET | Application health check |

## Database

FitBuddy uses SQLite by default.

The database file is intentionally **not included in this GitHub package** because it can contain user data. The application automatically creates the required tables when it starts.

## Security Notes

- Keep `GEMINI_API_KEY` private.
- Change `ADMIN_TOKEN` before deploying.
- Do not commit `.env`, databases containing real user data, virtual environments, or Python cache files.
- For production deployment, use a proper secret-management solution and review authentication/authorization requirements.

## AI Safety

FitBuddy is designed to provide general fitness guidance. Generated plans are not a substitute for medical or professional advice. Users should seek qualified professional guidance for injuries, chronic conditions, severe pain, pregnancy, eating disorders, or other situations requiring individualized care.

## License

Add your preferred open-source license before publishing if you want others to reuse the project.
